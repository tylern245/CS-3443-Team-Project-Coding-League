package application;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.scene.control.TextArea;

public class Part2Controller implements EventHandler<ActionEvent>{
	
	@FXML
	TextArea course1;
	
	@FXML
	TextArea course2;
	
	@FXML
	TextArea course3;
	
	@FXML
	TextArea course4;
	
	@FXML
	TextArea course5;
	
	@FXML
	TextArea course6;
	
	@FXML
	TextArea course7;
	
	@FXML
	TextArea course8;
	
	@Override
	public void handle(ActionEvent arg0) {
		// TODO Auto-generated method stub
		
	}

	public void showInformation(int i, String string) {
		if(i == 0) {
			course1.setText(string);
		}
		else if(i == 1) {
			course2.setText(string);
		}
		else if(i == 2) {
			course3.setText(string);
		}
		else if(i == 3) {
			course4.setText(string);
		}
		else if(i == 4) {
			course5.setText(string);
		}
		else if(i == 5) {
			course6.setText(string);
		}
		else if(i == 6) {
			course7.setText(string);
		}
		else if(i == 7) {
			course8.setText(string);
		}
		
	}

}
