package application;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import java.io.IOException;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;

public class HomePageController 
{
	@FXML private Button coursesButton;
	@FXML private Button calculatorButton;
	
	@FXML
	public void openCourses()
	{
		
	}
	
	@FXML
	public void openCalculator()
	{
		
	}
}
	
	
